import java.util.ArrayList;

public class JogadorRA170272New extends Jogador {
	private ArrayList<CartaLacaio> lacaios;
	//private ArrayList<CartaLacaio> lacaiosOponente;

	/**
	  * O método construtor do JogadorAleatorio.
	  *
	  * @param maoInicial Contém a mão inicial do jogador. Deve conter o número de cartas correto dependendo se esta classe Jogador que está sendo construída é o primeiro ou o segundo jogador da partida.
	  * @param primeiro   Informa se esta classe Jogador que está sendo construída é o primeiro jogador a iniciar nesta jogada (true) ou se é o segundo jogador (false).
	  */
	public JogadorRA170272New(ArrayList<Carta> maoInicial, boolean primeiro){

		primeiroJogador = primeiro;
		mao = maoInicial;
		lacaios = new ArrayList<CartaLacaio>();
		//lacaiosOponente = new ArrayList<CartaLacaio>();

		// Mensagens de depuração:
		System.out.println("*Classe JogadorRA170272New* Sou o " + (primeiro?"primeiro":"segundo") + " jogador (classe: JogadorAleatorio)");
		System.out.println("Mao inicial:");
		for(int i = 0; i < mao.size(); i++)
			System.out.println("ID " + mao.get(i).getID() + ": " + mao.get(i));
	}

	/**
	  * Um método que processa o turno de cada jogador. Este método deve retornar as jogadas do Jogador decididas para o turno atual (ArrayList de Jogada).
	  *
	  * @param mesa   O "estado do jogo" imediatamente antes do início do turno corrente. Este objeto de mesa contém todas as informações 'públicas' do jogo (lacaios vivos e suas vidas, vida dos heróis, etc).
	  * @param cartaComprada   A carta que o Jogador recebeu neste turno (comprada do Baralho). Obs: pode ser null se o Baralho estiver vazio ou o Jogador possuir mais de 10 cartas na mão.
	  * @param jogadasOponente   Um ArrayList de Jogada que foram os movimentos utilizados pelo oponente no último turno, em ordem.
	  * @return            um ArrayList com as Jogadas decididas
	  */
	public ArrayList<Jogada> processarTurno (Mesa mesa, Carta cartaComprada, ArrayList<Jogada> jogadasOponente){
		
		int minhaMana;
		
		if(cartaComprada != null)
			mao.add(cartaComprada);
		if(primeiroJogador){
			minhaMana = mesa.getManaJog1();
			//minhaVida = mesa.getVidaHeroi1();
			lacaios = mesa.getLacaiosJog1();
			//lacaiosOponente = mesa.getLacaiosJog2();
			System.out.println("--------------------------------- Começo de turno pro jogador1");
		}
		else{
			minhaMana = mesa.getManaJog2();
			//minhaVida = mesa.getVidaHeroi2();
			lacaios = mesa.getLacaiosJog2();
			//lacaiosOponente = mesa.getLacaiosJog1();
			System.out.println("--------------------------------- Começo de turno pro jogador2");
		}

		ArrayList<Jogada> minhasJogadas = new ArrayList<Jogada>();
		
		//O laco abaixo Ataca com os lacaios da mesa
		for(int i = 0; i<lacaios.size(); i++){
			Jogada atq = new Jogada(TipoJogada.ATAQUE, lacaios.get(i), null);
			minhasJogadas.add(atq);
		}
		// O laço abaixo baixa lacaios encontrados para a mesa se houver mana disponível.
		for(int i = 0; i < mao.size(); i++){
			Carta card = mao.get(i);
			if(card instanceof CartaLacaio && card.getMana() <= minhaMana){
				Jogada lac = new Jogada(TipoJogada.LACAIO, card, null);
				minhasJogadas.add(lac);
				minhaMana -= card.getMana();
				System.out.println("Jogada: Decidi uma jogada de baixar o lacaio: "+ card);
				mao.remove(i);
			}
		}
		// O laço abaixo baixa cartas magia encontradas para a mesa caso haja mana disponível.
		for(int i = 0; i < mao.size(); i++){
			Carta card = mao.get(i);
			if(card instanceof CartaMagia && card.getMana() <= minhaMana){
				//cartasTurno.add(card);
				Jogada mag;
				//Buffa um lacaio se existir
				if(((CartaMagia)card).getMagiaTipo() == TipoMagia.BUFF){
					if(lacaios.size()==0){
						continue;
					}
					else{
						mag = new Jogada(TipoJogada.MAGIA, card, lacaios.get(0));
						System.out.println("Jogada: Decidi uma jogada de buffar o lacaio:"+ lacaios.get(0) +" com a magia: "+ card);
					}
				}
				else{
					//nao diferencia magia do tipo alvo ou area pois está sempre mirando no heroi
					mag = new Jogada(TipoJogada.MAGIA, card, null);
					System.out.println("Jogada: Decidi uma jogada de baixar a magia: "+ card);
					
				}
				minhasJogadas.add(mag);
				minhaMana -= card.getMana();
				mao.remove(i);
			}
		}
		if(minhaMana>=2){
			Jogada atq = new Jogada(TipoJogada.PODER, null, null);
			minhasJogadas.add(atq);
			minhaMana -= 2;
		}
		
		
		return minhasJogadas;
	}
}
