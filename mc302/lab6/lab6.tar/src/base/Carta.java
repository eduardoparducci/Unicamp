package base;

public class Carta implements Comparable<Carta>{
	
	private int ID;
	private String nome;
	private int custoMana;
	
	public Carta(int ID, String nome, int custoMana){
		this.ID = ID;
		this.nome = nome;
		this.custoMana = custoMana;
	}
	public Carta(String nome, int custoMana){
		this.nome = nome;
		this.custoMana = custoMana;
	}
	
	//Métodos Gets
	public int getID(){
		return this.ID;
	}
	public String getNome(){
		return this.nome;
	}
	public int getCustoMana(){
		return this.custoMana;
	}
	
	//Métodos Sets
	public void setID(int ID){
		this.ID = ID;
	}
	public void setNome(String nome){
		this.nome = nome;
	}
	public void setCustoMana(int custoMana){
		this.custoMana = custoMana;
	}
	
	@Override
	public String toString(){
		String out;
		out = this.nome + "(ID=" + this.ID + ")\nMana" + this.custoMana + "\n";
		return out;
	}
	@Override
	public boolean equals(Object obj){
		if(this == obj){
			return true;
		}
		if(!(obj instanceof Carta)){
			return false;
		}
		
		Carta c = (Carta) obj;
		
		if(this.nome == null || c.nome == null){
			return false;
		}
		
		return (this.ID == c.ID && this.nome.equals(c.nome)); 
	}
	@Override
	public int hashCode(){
		int hash = 3;
		hash = 67 * hash + this.ID;
		hash = 13 * hash + (this.nome != null ? nome.hashCode() : 0);
		return hash;
	}
	@Override
	public int compareTo(Carta o) {
		return this.ID - o.ID;
	}
}
