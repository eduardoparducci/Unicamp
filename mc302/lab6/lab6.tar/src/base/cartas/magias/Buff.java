package base.cartas.magias;
import base.*;
import base.cartas.Lacaio;
public class Buff extends Magias{

	private int aumentoAtaque;
	private int aumentoVida;
	public Buff(int ID, String nome, int custoMana, int aumentoAtaque, int aumentoVida){
		super(ID, nome, custoMana);
		this.aumentoAtaque = aumentoAtaque;
		this.aumentoVida   = aumentoVida;
		
	}
	public Buff(String nome, int custoMana, int aumentoAtaque, int aumentoVida){
		super(nome, custoMana);
		this.aumentoAtaque = aumentoAtaque;
		this.aumentoVida   = aumentoVida;
	}
	public String toString(){
		return super.toString();
	}
	
	public void usar(Carta alvo){
		((Lacaio) alvo).setVidaAtual(((Lacaio) alvo).getVidaAtual()+this.aumentoVida);
		((Lacaio) alvo).setAtaque(((Lacaio) alvo).getAtaque()+this.aumentoAtaque);
	}
}
