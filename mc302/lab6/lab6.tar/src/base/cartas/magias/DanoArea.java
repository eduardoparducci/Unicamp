package base.cartas.magias;
import java.util.List;
import base.*;

public class DanoArea extends Dano{

	public DanoArea(int ID, String nome, int custoMana, int dano){
		super(ID, nome, custoMana, dano);
	}
	public DanoArea(String nome, int custoMana, int dano){
		super(nome, custoMana, dano);
	}
	public String toString(){
		return super.toString();
	}
	public void usar(List<Carta> alvos){
		for(Carta alvo : alvos){
			super.usar(alvo);
		}
	}
	
}
