package base.cartas.magias;
import base.*;
import base.cartas.Lacaio;
public class Dano extends Magias{

	private int dano;
	
	public Dano(int ID, String nome, int custoMana, int dano){
		super(ID, nome, custoMana);
		this.dano = dano;
	}
	public Dano(String nome, int custoMana, int dano){
		super(nome, custoMana);
		this.dano = dano;
	}
	public int getDano(){
		return this.dano;
	}
	public String toString(){
		return super.toString() + "Dano causado =" + dano;
	}
	
	public void usar(Carta alvo){
		((Lacaio) alvo).setVidaAtual(((Lacaio) alvo).getVidaAtual() - dano);
	}
}