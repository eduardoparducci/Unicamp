//Classe Main.java
/* Classe usada para instanciar objetos das classes CartaLacaio e CartaMagia
 * Autor: Eduardo Parducci
 * Ultima modificacao:14/03/2017
 */

import com.eduardo.base.*;
import com.eduardo.util.*;

public class Main {

	public static void main(String[] args) {

		//instanciando objetos
		CartaLacaio lac1 = new CartaLacaio(1, "Frodo Bolseiro", 2, 1, 1);
		CartaLacaio lac2 = new CartaLacaio(2, "Aragon", 5, 7, 6);
		CartaLacaio lac3 = new CartaLacaio(3, "Legolas", 8, 4, 6);
		BaralhoArrayList baralho  = new BaralhoArrayList(); 
		
		Util.buff(lac1, 5);
		Util.buff(lac2, 3);
		baralho.adicionarCarta(lac1);
		baralho.adicionarCarta(lac2);
		baralho.adicionarCarta(lac3);
		
		
		baralho.embaralhar();
		System.out.println("Carta comprada:" + baralho.comprarCarta().toString());
		
	}


}
