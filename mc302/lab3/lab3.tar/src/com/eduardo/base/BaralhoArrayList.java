package com.eduardo.base;
import java.util.ArrayList;
import java.util.Collections;;

public class BaralhoArrayList{
    private ArrayList<CartaLacaio> vetorCartas;

    public BaralhoArrayList(){
        vetorCartas = new ArrayList<CartaLacaio>();
    }

    public void adicionarCarta(CartaLacaio card){
        if(vetorCartas.size() < 30)
            vetorCartas.add(card);
    }
    public CartaLacaio comprarCarta(){
    	CartaLacaio ult = vetorCartas.get(vetorCartas.size()-1);
        vetorCartas.remove(vetorCartas.size()-1);
        return ult;
    }

    public void embaralhar(){
        Collections.shuffle(vetorCartas);
        //imprimir baralho em ordem reversa
        Collections.reverse(vetorCartas);
        System.out.println(vetorCartas.toString());
        Collections.reverse(vetorCartas);
    }
}
