package com.eduardo.util;
import com.eduardo.base.*;

/*Classe CartaLacaio.java
 * Classe que contempla atributos e metodos de uma carta lacaio
 * Autor: Eduardo Parducci
 * Ultima modificacao:02/04/2017
 */

 public class Util {

     public static int MAX_CARDS = 30;

     public static void buff(CartaLacaio lac, int a){
 	 	buff(lac,a,a);
 	 }
 	 public static void buff(CartaLacaio lac, int a, int v){
 	 	 if(a <= 0 || v <= 0){
 	 	 	 return;
 	 	 }
 		 lac.setAtaque(lac.getAtaque()+a);
 		 lac.setVidaMaxima(lac.getVidaMaxima()+v);
 		 alterarNomeFortalecido(lac);
 	 }
 	 
     private static void alterarNomeFortalecido(CartaLacaio lac){
         lac.setNome(lac.getNome() + " Buffed");
     }
 }

