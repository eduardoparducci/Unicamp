//Classe Main.java
/* Classe usada para instanciar objetos das classes CartaLacaio e CartaMagia
 * Autor: Eduardo Parducci
 * Ultima modificacao:14/03/2017
 */
public class Main {

	public static void main(String[] args) {
		
		//instanciando objetos
		CartaLacaio lac1 = new CartaLacaio(1, "Lacaio 1", 2, 1, 1);
		CartaLacaio lac2 = new CartaLacaio(2, "Lacaio 2", 5, 7, 6);
		CartaLacaio lac3 = new CartaLacaio(3, "Lacaio 3", 8, 4, 6);
		CartaMagia mag1  = new CartaMagia(4, "Magia 1", 4, true, 7);
		CartaMagia mag2  = new CartaMagia(5, "Magia 2", 3, false, 2);
		CartaMagia mag3  = new CartaMagia(6, "Magia 3", 4, false, 5);
		
		//impressao dos objetos
		System.out.println("Primeiro Lacaio:\n"+lac1);
		System.out.println("Segundo Lacaio:\n"+lac2);
		System.out.println("Terceiro Lacaio:\n"+lac3);
		System.out.println("Primeira Magia:\n"+mag1);
		System.out.println("Segunda Magia:\n"+mag2);
		System.out.println("Terceira Magia:\n"+mag3);
	}

}
