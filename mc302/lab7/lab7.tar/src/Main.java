import base.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.LinkedList;

public class Main {
 
	public static void main(String[] args) {
		
		long t,t2; //tempo de processamento
		ArrayList<Carta> cartasAL = new ArrayList<Carta>();
		LinkedList<Carta> cartasLL = new LinkedList<Carta>();
		HashSet<Carta> cartasHS= new HashSet<Carta>();
		TreeSet<Carta> cartasTS= new TreeSet<Carta>();
		
		// Adiciona 10000 cartas às estruturas
		for(int i=0 ; i<10000 ; i++){
			Carta carta = new Carta(i+1,("Carta" + i),2);
			cartasAL.add(carta);
			cartasLL.add(carta);
			cartasHS.add(carta);
			cartasTS.add(carta);
		}
		
		// Busca em Linked utilizando List#get(int i)
		t = System.nanoTime();
		for(int i=0 ; i<10000 ; i++){
			cartasLL.get(i);
		}
		t = (System.nanoTime() - t)/1000;
		System.out.println("Operacao: Busca em LinkedList List#get(int i)\nTempo:" + t + "us");
		
		// Busca em Array utilizando List#contains(Object o)
		Collections.shuffle(cartasLL);
		t2 = System.nanoTime();
		for(int i=0 ; i<10000 ; i++){
			cartasAL.contains(cartasLL.get(i));
		}
		t2 = (System.nanoTime() - t2)/1000 - t; // Onde t é o tempo gasto para executar cartasLL.get(i)
		System.out.println("Operacao: Busca em ArrayList List#contains(Object o)\nTempo:" + t2 + "us");
		
		// Busca em Array utilizando List#get(int i)
		t = System.nanoTime();
		for(int i=0 ; i<10000 ; i++){
			cartasAL.get(i);
		}
		t = (System.nanoTime() - t)/1000;		
		System.out.println("Operacao: Busca em ArrayList List#get(int i)\nTempo:" + t + "us");
		
		// Busca em Linked utilizando List#contains(Object o)
		t2 = System.nanoTime();
		for(int i=0 ; i<10000 ; i++){
			cartasLL.get(i);
		}
		t2 = (System.nanoTime() - t2)/1000 - t; // Onde t é o tempo gasto para executar cartasAL.get(i)
		System.out.println("Operacao: Busca em LinkedList List#contains(Object o)\nTempo:" + t2 + "us");
		
		// Busca em Hash
		t2 = System.nanoTime();
		for(int i=0 ; i<10000 ; i++){
			cartasHS.contains(cartasAL.get(i));
		}
		t2 = (System.nanoTime() - t2)/1000 - t; // Onde t é o tempo gasto para executar cartasAL.get(i)
		System.out.println("Operacao: Busca em HashSet List#contains(Object o)\nTempo:" + t2 + "us");
		
		// Busca em Tree
		t2 = System.nanoTime();
		for(int i=0 ; i<10000 ; i++){
			cartasTS.contains(cartasAL.get(i));
		}
		t2 = (System.nanoTime() - t2)/1000 - t; // Onde t é o tempo gasto para executar cartasAL.get(i)
		System.out.println("Operacao: Busca em TreeSet List#contains(Object o)\nTempo:" + t2 + "us");
		
		

		/* O trecho abaixo executa as atividades restantes do enunciado
		Carta c1 = new Carta(100,"Légolas",1);
		Carta c1 = new Carta(100,"Légolas",1);
		Carta c2 = new Carta(101,"Légolas",1);
		Carta c3 = new Carta(100,"Légolas 2",1);
		Carta c1_copia = new Carta(100,"Légolas",1);
		Baralho bar  = new Baralho();
		Baralho bar2 = new Baralho();
		Baralho bar_copia = new Baralho();
		
		// Verifica se as estruturas admitem cartas repetidas
		cartasLL.add(c1);
		cartasLL.add(c1);
		cartasAL.add(c1);
		cartasAL.add(c1);
		cartasHS.add(c1);
		cartasHS.add(c1);
		cartasTS.add(c1);
		cartasTS.add(c1);
		
		
		// Adiciona cartas ao baralho bar
		bar.adicionarCarta(c1);
		bar.adicionarCarta(c2);
		bar.adicionarCarta(c3);
		bar.adicionarCarta(c1_copia);
		
		// Adiciona cartas ao baralho bar2
		bar2.adicionarCarta(c1);
		bar2.adicionarCarta(c3);
		bar2.adicionarCarta(c2);
		bar2.adicionarCarta(c1_copia);
		
		// Adiciona cartas ao baralho bar_copia
		bar_copia.adicionarCarta(c1);
		bar_copia.adicionarCarta(c2);
		bar_copia.adicionarCarta(c3);
		bar_copia.adicionarCarta(c1_copia);
		
		// Testar método equals da classe baralho
		if(!(bar.equals(bar2))){
			System.out.println("bar != bar2");
		}
		if(bar.equals(bar_copia)){
			System.out.println("bar == bar_copia");
		}
		
		// Laço para testar método equals da carta 1 de bar
		for(int i=0 ; i<bar.getSize() ; i++){
			Carta carta = bar.getCarta(i);
			if(c1.equals(carta)){
				System.out.println(c1.getID() + "-" + c1.getNome() + " eh igual a: " + carta.getID() + "-" + carta.getNome());
			}
			else{
				System.out.println(c1.getID() + "-" + c1.getNome() + " nao eh igual a: " + carta.getID() + "-" + carta.getNome());
			}
		}*/
	}
}
