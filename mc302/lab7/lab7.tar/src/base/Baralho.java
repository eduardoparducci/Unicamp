package base;

import java.util.ArrayList;
import java.util.Collections;

public class Baralho{
    private ArrayList<Carta> vetorCartas;

    public Baralho(){
        vetorCartas = new ArrayList<Carta>();
    }

    public void adicionarCarta(Carta card){
        if(vetorCartas.size() < 30)
            vetorCartas.add(card);
    }
    public Carta comprarCarta(){
    	Carta ult = vetorCartas.get(vetorCartas.size()-1);
        vetorCartas.remove(vetorCartas.size()-1);
        return ult;
    }
    public int getSize(){
    	return vetorCartas.size();
    }
    public Carta getCarta(int i){
    	return vetorCartas.get(i);
    }
    public ArrayList<Carta> getVetor(){
    	return this.vetorCartas;
    }

    public void embaralhar(){
        Collections.shuffle(vetorCartas);
        //imprimir baralho
        System.out.println(vetorCartas.toString());
    }
    
    @Override
    public boolean equals(Object obj){
    	/*
    	if(this == obj){
    		return true;
    	}
    	if(!(obj instanceof Baralho)){
    		return false;
    	
    	}
    	Baralho baralho = (Baralho)obj;
   		*/
    	return vetorCartas.equals(((Baralho)obj).getVetor()); 	
    }
	@Override
	public int hashCode(){
		return 3 * 67 + (this.vetorCartas != null ? this.vetorCartas.hashCode() : 0);
	}
}
