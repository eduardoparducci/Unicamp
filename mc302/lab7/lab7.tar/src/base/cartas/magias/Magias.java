package base.cartas.magias;
import base.Carta;

public class Magias extends Carta{

	//construtores
	public Magias(int ID, String nome, int custoMana){
		super(ID, nome, custoMana);
	}
	public Magias(String nome, int custoMana){
		super(nome, custoMana);
	}
	
	public String toString(){
		return super.toString();
	}
}
