//Classe Main.java
/* Classe usada para instanciar objetos das classes CartaLacaio e CartaMagia
 * Autor: Eduardo Parducci
 * Ultima modificacao:14/03/2017
 */
public class Main {

	public static void main(String[] args) {

		//instanciando objetos
		CartaLacaio lac1 = new CartaLacaio(1, "Frodo Bolseiro", 2, 1, 1);
		CartaLacaio lac2 = new CartaLacaio(2, "Aragon", 5, 7, 6);
		CartaLacaio lac3 = new CartaLacaio(3, "Legolas", 8, 4, 6);
		CartaMagia mag1  = new CartaMagia(4, "You shall not pass", 4, true, 7);
		CartaMagia mag2  = new CartaMagia(5, "Telecinese", 3, false, 2);
		//item 1
		CartaLacaio lac4 = new CartaLacaio(6,"Lacaio reduzido", 3);
		//item 4
		CartaLacaio lac5 = new CartaLacaio(lac2);

		//item 1
		System.out.println("-----ITEM 1-----");
		System.out.println(lac4);
		//item 2
		System.out.println("-----ITEM 2-----");
		lac1.setAtaque(lac3.getAtaque());
		System.out.println(lac1);
		//item 3
		System.out.println("-----ITEM 3-----");
		System.out.println(mag1);
		//item 4
		System.out.println("-----ITEM 4-----");
		System.out.println(lac5);
		System.out.println(lac2);
		//item 5
		System.out.println("-----ITEM 5-----");
		System.out.println(mag1.nome);
		System.out.println(mag1.getNome());
		//item 6
		System.out.println("-----ITEM 6-----");
		lac1.buff(3);
		lac2.buff(1, 2);
		System.out.println(lac1);
		System.out.println(lac2);

	}


}
