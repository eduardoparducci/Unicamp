import base.*;
import base.cartas.Lacaio;

public class Main {

	public static void main(String[] args) {

		Baralho baralho  = new Baralho(); 
		Lacaio lac1 = new Lacaio(1, "Frodo Bolseiro", 2, 4, 5);
		Lacaio lac2 = new Lacaio(2, "Aragon", 5, 5, 5);
		Lacaio lac3 = new Lacaio(3, "Legolas", 8, 2, 3);
		baralho.adicionarCarta(lac1);
		baralho.adicionarCarta(lac2);
		baralho.adicionarCarta(lac3);
		
		
		baralho.embaralhar();
		
	}


}