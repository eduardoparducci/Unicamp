package util;

import base.cartas.Lacaio;

public class Util {

    public static int MAX_CARDS = 30;

    public static void buff(Lacaio lac, int a){
 		buff(lac,a,a);
 	}
 	public static void buff(Lacaio lac, int a, int v){
 		 if(a <= 0 || v <= 0){
 		 	 return;
 		 }
 		lac.setAtaque(lac.getAtaque()+a);
 		lac.setVidaMaxima(lac.getVidaMaxima()+v);
 		alterarNomeFortalecido(lac);
 	}
 	 
    private static void alterarNomeFortalecido(Lacaio lac){
        lac.setNome(lac.getNome() + " Buffed");
    }
}

