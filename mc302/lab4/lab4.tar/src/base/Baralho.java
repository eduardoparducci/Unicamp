package base;

import java.util.ArrayList;
import java.util.Collections;

public class Baralho{
    private ArrayList<Carta> vetorCartas;

    public Baralho(){
        vetorCartas = new ArrayList<Carta>();
    }

    public void adicionarCarta(Carta card){
        if(vetorCartas.size() < 30)
            vetorCartas.add(card);
    }
    public Carta comprarCarta(){
    	Carta ult = vetorCartas.get(vetorCartas.size()-1);
        vetorCartas.remove(vetorCartas.size()-1);
        return ult;
    }

    public void embaralhar(){
        Collections.shuffle(vetorCartas);
        //imprimir baralho em ordem reversa
        Collections.reverse(vetorCartas);
        System.out.println(vetorCartas.toString());
        Collections.reverse(vetorCartas);
    }
}
