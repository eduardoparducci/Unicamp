package base.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import base.cartas.Carta;
import base.exception.BaralhoVazioException;
import base.service.BaralhoService;
import base.service.CartaService;
import util.Util;

public class BaralhoServiceImpl implements BaralhoService {
	
	/**
	 * Preenche o baralho com min(MAX_CARTAS, tamanho) cartas geradas aleatoriamente
	 * 
	 * @param gerador objeto da classe RANDOM
	 * @param tamanho tamanho do baralho
	 * @param maxMana limitante superior no gasto de mana
	 * @param maxAtaque limitante superior no valor do ataque
	 * @param maxVida limitante superior no valor de vida
	 * @return ArrayList cartas
	 */

	@Override
	public List<Carta> preencheAleatorio(Random gerador, int tamanho, int maxMana, int maxAtaque, int maxVida) {
		List<Carta> cartas = new ArrayList<Carta>();
		CartaService cartaService = new CartaServiceImpl();
		
		tamanho = (tamanho <= Util.MAX_CARDS) ? tamanho : Util.MAX_CARDS;
		for(int i = 0; i < tamanho; ++i) {
			cartas.add(cartaService.geraCartaAleatoria(gerador, maxMana, maxAtaque, maxVida, null));
		}
		
		if(cartas.isEmpty()){
			throw new BaralhoVazioException();
		}
		return cartas;
	}
}