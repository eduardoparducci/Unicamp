package base.service.impl;

import java.util.Random;

import base.Baralho;
import base.Mesa;
import base.cartas.TipoCarta;
import base.exception.MesaNulaException;
import base.service.CartaService;
import base.service.MesaService;

public class MesaServiceImpl implements MesaService {
	
	private CartaService cartaService = new CartaServiceImpl();
	int maxLacaios = 10;
	int maxMana = 2;
	int maxAtaque = 6;
	int maxVida = 6;
	
	@Override 
	public Mesa adicionaLacaios(Mesa mesa, Random gerador, TipoCarta tipo) throws MesaNulaException{
		
		if(mesa == null){
			throw new MesaNulaException();
		}
		
		for (int i = 0; i < maxLacaios; i++) {
			mesa.getLacaiosP().add(cartaService.geraCartaAleatoria(gerador, maxMana, maxAtaque, maxVida, TipoCarta.LACAIO));
			mesa.getLacaiosS().add(cartaService.geraCartaAleatoria(gerador, maxMana, maxAtaque, maxVida, TipoCarta.LACAIO));
		}
		return mesa;
	}
	@Override
	public Mesa addMaoInicial(Mesa mesa, Baralho baralhoP, Baralho baralhoS, int MAO_INI){
		for (int i = 0; i < MAO_INI; i++) {
			mesa.getMaoP().add(baralhoP.comprar());
			mesa.getMaoS().add(baralhoS.comprar());
		}
		mesa.getMaoS().add(baralhoS.comprar());
		return mesa;
	}

}