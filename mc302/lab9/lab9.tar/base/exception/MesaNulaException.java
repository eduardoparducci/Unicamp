package base.exception;

@SuppressWarnings("serial")
public class MesaNulaException extends Exception {
	public MesaNulaException() {
        super();
    }
    public MesaNulaException(String message) {
        super(message);
    }
    public MesaNulaException(String message, Throwable cause) {
        super(message, cause);
    }
    public MesaNulaException(Throwable cause) {
        super(cause);
    }
    protected MesaNulaException(String message, Throwable cause,boolean enableSuppression,boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
