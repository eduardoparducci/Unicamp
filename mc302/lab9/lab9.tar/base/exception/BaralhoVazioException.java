package base.exception;

@SuppressWarnings("serial")
public class BaralhoVazioException extends IllegalArgumentException {

    public BaralhoVazioException() {
        super();
    }
    public BaralhoVazioException(String s) {
        super(s);
    }
    public BaralhoVazioException(String message, Throwable cause) {
        super(message, cause);
    }
    public BaralhoVazioException(Throwable cause) {
        super(cause);
    }
}
